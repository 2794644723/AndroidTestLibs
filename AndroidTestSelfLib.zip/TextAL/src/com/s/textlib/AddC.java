package com.s.textlib;

public class AddC {

	public static int add(int n, int m){
		return n+m;
	}
}

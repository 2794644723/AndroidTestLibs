package com.example.ceshi01;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import com.s.textlib.AddC;

public class testlAc extends Activity{

	Button b;
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		int m = AddC.add(100, 50);
		Log.e("========="+m, "=========="+m);
		setContentView(R.layout.maintest);
		
		b = (Button) findViewById(R.id.button1);
		b.setText(""+m);
	}
	
	
}
